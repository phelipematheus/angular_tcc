import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-funcionaliade-list',
  templateUrl: './funcionaliade-list.component.html',
  styleUrls: ['./funcionaliade-list.component.scss']
})
export class FuncionaliadeListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
